<?php

include "db-connect.php";
  $email = $_SESSION["cname"];
        
   $Sdu_id = $_SESSION["Sdu_id"];

//echo $login_email; exit;
          
          $logout=date("Y/m/d h:i:s");
//echo "SELECT * FROM `login_details` WHERE emp_id='$login_id' ORDER BY emp_id DESC"; exit;

$SELECT_query1 = mysqli_query($db, "SELECT * FROM `login_details` WHERE Sdu_id='$Sdu_id' ORDER BY id DESC");
	$s_id_1 = (mysqli_fetch_assoc($SELECT_query1));
    $logout_id=$s_id_1['id'];

//echo "UPDATE `login_details` SET `logout_time`='$logout' WHERE id='$logout_id'"; exit;
$query = mysqli_query($db,"UPDATE `login_details` SET `logout_time`='$logout' WHERE id='$logout_id'");
unset($_SESSION["Sdu_id"]);
unset($_SESSION["email"]);
 session_destroy();
          

//header("Location:index.php"); 
?>