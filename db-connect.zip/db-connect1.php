<?php 

date_default_timezone_set("Asia/Kolkata");


error_reporting(E_ALL);
ini_set("display_errors", 0); 
$db = mysqli_connect("localhost","l2v6oc6o4ke9","Balabalalove@1","new_db_leave"); 

/*if($db)
	 {
		 
		 echo "YES";
	 }
	 else  
	 {
		 
		 echo "No";
	 } */

 // if($db){echo "connected";}
$created_date=date("Y-m-d H:i:s");
	 
?>