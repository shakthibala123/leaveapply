<?php 
include("db-connect.php");
if (isset($_POST['name'])) {
    $id= $_POST['id'];
    $name= $_POST['name'];
    $file = $_POST['file'];
    //   $path = "uploads/" . basename($file); // 5
    // if (move_uploaded_file($file['file'], $path)) {
    //     echo "insert";
    // }
    //   else  {
    //     echo 'not insert';
    //     }  

    

    $query = mysqli_query($conn,"INSERT INTO db_conn(`id`,`name`,`file`)VALUES('$id','$name','$file')");
     
        $data = "inserted";
   die($data);

  



}


 ?>

<html lang="en" class="wf-poppins-n4-active wf-poppins-n6-active wf-poppins-n3-active wf-poppins-n5-active wf-roboto-n5-active wf-poppins-n7-active wf-roboto-n3-active wf-roboto-n4-active wf-roboto-n6-active wf-roboto-n7-active wf-active"><!-- begin::Head --><head>
        <meta charset="utf-8">
        <title>
            Metronic | State Colors
        </title>
        <meta name="description" content="State colors">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!--begin::Web font -->
        <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700%7CRoboto:300,400,500,600,700" media="all"><script>
          WebFont.load({
            google: {"families":["Poppins:300,400,500,600,700","Roboto:300,400,500,600,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
        </script>
        <!--end::Web font -->
        <!--begin::Base Styles -->
        <link href="../../assets/vendors/base/vendors.bundle.css" rel="stylesheet" type="text/css">
        <link href="../../assets/demo/default/base/style.bundle.css" rel="stylesheet" type="text/css">
        <!--end::Base Styles -->
        <link rel="shortcut icon" href="../../assets/demo/default/media/img/logo/favicon.ico">
    <style type="text/css">.im-caret {
    -webkit-animation: 1s blink step-end infinite;
    animation: 1s blink step-end infinite;
}

@keyframes blink {
    from, to {
        border-right-color: black;
    }
    50% {
        border-right-color: transparent;
    }
}

@-webkit-keyframes blink {
    from, to {
        border-right-color: black;
    }
    50% {
        border-right-color: transparent;
    }
}

.im-static {
    color: grey;
}
</style><style type="text/css">/* Chart.js */
@-webkit-keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}@keyframes chartjs-render-animation{from{opacity:0.99}to{opacity:1}}.chartjs-render-monitor{-webkit-animation:chartjs-render-animation 0.001s;animation:chartjs-render-animation 0.001s;}</style></head>
<body class="m-page--fluid m--skin- m-content--skin-light2 m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default">
     <header class="m-grid__item    m-header " data-minimize-offset="200" data-minimize-mobile-offset="200 " style="background-color:#AC59FF; " >
      <div class="m-grid m-grid--hor m-grid--root m-page">
      <div class="m-container m-container--fluid m-container--full-height">
        <div class="m-stack m-stack--ver m-stack--desktop">
          <div class="m-container" style="margin-top: 0px;">
            <h5 class="m-nav__item m-topbar__user-profile m-topbar__user-profile--img  m-dropdown m-dropdown--medium m-dropdown--arrow m-dropdown--header-bg-fill m-dropdown--align-right m-dropdown--mobile-full-width m-dropdown--skin-light" data-dropdown-toggle="click">
              <a href="#" class="m-nav__link m-dropdown__toggle">
              <span class="m-topbar__userpic">
              <img src="../../assets/app/media/img/users/user4.jpg" class="m--img-rounded m--marginless m--img-centered" alt="">
              </span>
              </a>
            </h5>
            <h3 class="m-stack text-warning"></h3>
          </div>
        </div>
      </div>
    </header>
    <br><br><br>
    <div class="m-container">
      <div class="m-content">
        <div class="row">
          <div class="col-lg-12">
            <!--begin::Portlet-->
            <br>
            <div class="m-portlet">
              <div class="m-portlet__head">
                <div class="m-portlet__head-caption">
                  <div class="m-portlet__head-title">
                    <span class="m-portlet__head-icon m--hide">
                    <i class="la la-gear"></i>
                    </span>
                    <h3 class="m-portlet__head-text text-info">
                      Register
                    </h3>
                  </div>
                </div>
              </div>
              <form class="m-form m-form--fit m-form--label-align-right m-form--group-seperator-dashed form_submit" method="POST">
                <div class="m-portlet__body">
                  <div class="form-group m-form__group row">
                      
                   
                    <div class="col-lg-6">
                      <label>
                      Enter ID:
                      </label>
                      <input type="text" class="form-control m-input" placeholder="Enter Id" name="id" id="id">
                      <span class="m-form__help">
                      Please emplyee ID
                      </span>
                    </div>

                    <div class="col-lg-6">
                      <label class="">
                      Enter name:
                      </label>
                      <input type="text" class="form-control m-input" placeholder="Enter Name" name="name" id="name">
                      <span class="m-form__help">
                      Please enter your Name
                      </span>
                    </div>
                     <div class="col-lg-6">
                      <label class="">
                      File Select:
                      </label>
                      <input type="file" class="form-control m-input" placeholder="Select File" name="file" id="uploaded_file">
                      <span class="m-form__help" >
                      Select Your File
                      </span>
                    </div>
                  </div>
           
                
                </div>
                <div class="m-portlet__foot m-portlet__no-border m-portlet__foot--fit">
                  <div class="m-form__actions m-form__actions--solid">
                    <div class="row">
                      <div class="col-lg-6">
                         <button type="submit" class="btn btn-info click" id="btn-submit" name="submit" >
                        Register
                        </button>
                       </div>

                       <br><br>
      </div>
              </form>
          </div>
                     <?php

$sql="SELECT * FROM db_conn";
$res=mysqli_query($conn,$sql);
?>
<br><br><hr><div class="m-container" style="margin-left:  15%; width:200%;">


            <table class="table table-striped table-hover table-responsive justify-content-center">
    <thead>

        <tr class="bg-primary text-white">
           
            <td>ID</td>
            <td>Name</td>
            <td>File Name</td>

            <td>Action</td>
        </tr>
    </thead>
    <tbody>
        <?php
            while($row=mysqli_fetch_array($res))
            {
        ?>
            <tr>
                
                <td><?php echo $row['id'];  ?></td>
                <td><?php echo $row['name'];  ?></td>
                 <td><?php echo $row['file'];  ?></td>

      
                
                <td>
                         <a href="download.php<?php echo $file; ?>" class="btn btn-info">download</a>
               
                </td>
            </tr>
        <?php
            }//While End
        ?>
    </tbody>
</table>


   
     
  
   
    

    <!-- <div class="modal fade" id="m_modal_2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" style="display: none;" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle">
              Modal title
            </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">
            ×
            </span>
            </button>
          </div>
          <div class="m-portlet__body">
            <div class="m-section__content">
              <table class="table m-table m-table--head-bg-success">
                <thead>
                  <tr>
                    <th>
                      Id
                    </th>
                    <th>
                      First Name
                    </th>
                    <th>
                      Contact Number
                    </th>
                    <th>
                      Address
                    </th>
                    <th>
                      PinCode
                    </th>
                    <th>
                      Gender
                    </th>
                  </tr>
                </thead>
                <?php 
                  $sql="SELECT * FROM `cus_table`";
                  $result = mysqli_query($conn, $sql);
                  
                  while($row = mysqli_fetch_assoc($result))
                   {
                  
                  ?>
                <tbody>
                  <tr>
                    <th scope="row">
                      1
                    </th>
                    <td>
                      <?php echo $row['username']?>  
                    </td>
                    <td>
                      <?php echo $row['number']?>
                    </td>
                    <td>
                      <?php echo $row['address']?>
                    </td>
                    <td>
                      <?php echo $row['pin']?>
                    </td>
                    <td>
                      <?php echo $row['sale']?>
                    </td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div> -->
    <!--  <button type="submit" class="btn btn-info" name="submit">
                        Register
                        </button> -->
    <script src="../../../assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
    <script src="../../../assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
<!--     <script>
      $(".click").on("click", function(e){ 
                  var data = $('#form_submit').serialize();
                  
                  $.ajax({
                     type:"POST",
                     data:data,                  
                     success:
                      function(data){
                          if(data=="inserted")
                          {
                           toastr.success("inserted successfully"); 
                      }
                       
                      }   
                  });
                  e.preventDefault();
              });  
    </script> -->

    <footer class="m-container--fluid" style="background-color:white; margin-bottom: 10px; padding: 20px;">
       <h4> <span class="text-"></span></h4>
        

    </footer>

    <script> 

$(".form_submit").on("submit", function(e){ 
            var data = $(this).serialize();
                
            $.ajax({
                type:"POST",
                data:data,  
                success: function(data){
          
 
                 if(data="inserted")
                 {
                        
                        toastr.success("Successfuly Inserted");
                 }else{

                         toastr.info("Updated successfully"); 
                }
                 
                }   
                });
            e.preventDefault();
        }); 
    </script>







</body>
</html>