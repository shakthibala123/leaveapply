
<?php
include "db-connect.php"; 
error_reporting(E_ALL);

ini_set('display_errors',0);
$login=date("Y/m/d h:i:s");

$date=date("d-M-Y");


if(isset($_POST['user_name'])){

      $email=$_POST['user_name'];
      $password=$_POST['password'];  
      $result = mysqli_query($db,"SELECT * FROM sdu_register WHERE email='$email' and password = '$password'");

$count = mysqli_num_rows($result);

    
    if($count == 1) 

{ 

    $row = mysqli_fetch_assoc($result);
    


    $_SESSION["cname"] = $row["email"]; 
        
    $_SESSION["Sdu_id"] =   $row["Sdu_id"];

        
    header('Location:dash.php'); 

}
    
}
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign in Form by Egsp</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
 <link rel="icon" type="image/x-icon" href="img/8.jpg">
    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">

</head>
<body style="background-image: url(img/desola-lanre-ologun-zYgV-NGZtlA-unsplash.jpg);">
    <div class="main">

        <section class="signup">
           
            <div class="container">
                <div class="signup-content">
                    <form method="POST" id="signup-form" class="signup-form" action="index.php"> 
                        <h2 class="form-title">Log In Today</h2>
                       
                        
                         <div class="form-group">
                            <input type="text" class="form-input" name="user_name" id="user_name" placeholder="Your email" required>
                        </div>
                      
                      
                   
                        <div class="form-group">
                            <input type="password" class="form-input" name="password" id="password-field" placeholder="Password" required>
                          
                        </div>
                   
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Sign In"/>
                        </div>
                          <div class="form-group">
                            <a href="forget.php">Forget Password!</a>
                        </div>
                    </form>
                    <p class="loginhere">
                        If Not Register Get account ? Ask To Class Teacher
                    </p>
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
 
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>