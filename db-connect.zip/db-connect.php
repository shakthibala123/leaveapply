<?php
session_start();
//$uname=$_SESSION["uname"];  
//$uid=$_SESSION["uid"];
include "db-connect1.php"; 
//if(!$uid && !$uname){header('Location:index.php');exit;}