<?php
include "db-connect.php";
$cc_id= $_POST["c_id"];

//echo $cc_id;exit;
//echo $cus_id;exit;
//echo "SELECT * FROM sdu_register WHERE Sdu_id='$cc_id'";exit;
$result1 = mysqli_query($db,"SELECT * FROM sdu_register WHERE Sdu_id='$cc_id'");
$cust_details = mysqli_fetch_assoc($result1);
if (isset($_POST['submit'])) {
  
  $Sdu_id = $_POST['Sdu_id'];

  //echo $Sdu_id;exit;
  //$cus_id =   $Sdu_id;
  $a = date('ymd');
  $b = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 6)), 0, 6);
  $c = strtoupper($b);
  $Leave_id = GSELE.$a.$c;
  $name = $_POST['name'];
  $mobile = $_POST['mobile'];
  $Depart = $_POST['Depart'];
  $from_da = $_POST['from_da'];
  $to_da = $_POST['to_da'];
  $address1 = $_POST['address1'];
  $Year = $_POST["Year"];
  $city = $_POST['city'];
  $email = $_POST['email'];
  $Sdu_created_date = $_POST['Sdu_created_date'];
  $reason = $_POST['reason'];
  $leave_status = "Pending";
  //$ticket_cc_date=date('d-m-Y');
  $leave_c_date=date("Y-m-d H:i:s");
  //$valid_date = $_POST['valid_date'];
  $today= date("d-m-Y");
  $leave = 'leave';
  $file = $_FILES['file']['name']; 
  $tmp_name1=$_FILES['file']['tmp_name']; 
  mkdir("Uploads/Customer/Ticket/");
  mkdir("Uploads/Customer/Ticket/".$Leave_id);
  mkdir("Uploads/Customer/Ticket/".$Leave_id."/".$leave); 
  mkdir("Uploads/Customer/Ticket/".$Leave_id."/".$leave."/".$today."/");
  $path=("Uploads/Customer/Ticket/".$Leave_id."/".$leave."/".$today."/");
  
    
  move_uploaded_file($tmp_name1,$path.$file);

$sql = mysqli_query($db,"INSERT INTO leave_management(`Sdu_id`,`Leave_id`,`name`,`mobile`,`Depart`,`address1`,`Year`,`city`,`email`,`Sdu_created_date`,`reason`,`from_lea`,`to_lea`,`leave_status`,`leave_c_date`,`file`,`path`)VALUES('$Sdu_id','$Leave_id','$name','$mobile','$Depart','$address1','$Year','$city','$email','$Sdu_created_date','$reason','$from_da','$to_da','$leave_status','$leave_c_date','$file','$path')");
  if($sql){
echo ("<script LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated');
  window.location.href='viewleave.php';
    </script>");
  }
  

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Sdutent - Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	 <link rel="icon" type="image/x-icon" href="img/8.jpg">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php
   include "aside.php";
   ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
                <?php
   include "header.php";
   ?>
      
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Leave Letter</h1>
          

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Apply Your Leave Online</h6>
            </div>
            <div class="card-body">
            
                <div class="row">
                  <div class="col-12">
                <form  method="POST" class="user" action="apply.php" enctype="multipart/form-data">
                    <input type="text" class="form-control"  name="Sdu_id" value="<?php echo $cust_details['Sdu_id'];?>"  hidden/>
                      <input type="text" class="form-control"  name="name" value="<?php echo $cust_details['name'].$cust_details['lastname'];?>"  hidden>
                      <input type="text" class="form-control"  name="mobile" value="<?php echo $cust_details['mobile'];?>"  hidden>
                      <input type="text" class="form-control"  name="Depart" value="<?php echo $cust_details['Depart'];?>"  hidden>

    <input type="text" class="form-control"  name="address1" value="<?php echo $cust_details['address'];?>"  hidden>
      <input type="text" class="form-control"  name="Year" value="<?php echo $cust_details['Year'];?>"  hidden>
          <input type="text" class="form-control"  name="city" value="<?php echo $cust_details['city'];?>"  hidden>
          <input type="text" class="form-control"  name="email" value="<?php echo $cust_details['email'];?>"  hidden>
            <input type="text" class="form-control"  name="Sdu_created_date" value="<?php echo $cust_details['created_date'];?>"  hidden>
                    <div class="form-group">
                   
                     <textarea class="form-control" name="reason" placeholder="Enter Reason"></textarea>
                    </div>
                    <div class="row">
                      <div class="col-4">
                       <label>From:</label>
                     <input type="date" class="form-control"  name="from_da">
                   </div>
                     <div class="col-4">
                         <label>To:</label>
                      <input type="date" class="form-control"  name="to_da">
                    </div>

                      </div>
                      <br>
                    <div class="form-group">
                      <input type="file" class="form-control" id="exampleInputPassword" name="file" placeholder="File">
                    </div>
                      <div class="form-group col-4">
                      <input type="submit" class="btn btn-info"  value="Apply Leave" name="submit">
                    </div>
  
                  </form>
                </div>

                </div>
             
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="index.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
