<?php
include "db-connect.php";
$cc_id= $_POST["c_id"];



$result = mysqli_query($db,"SELECT * FROM leave_management WHERE Leave_id='$cc_id'");

$cust_details = mysqli_fetch_assoc($result);

$result_1 = mysqli_query($db,"SELECT * FROM chat WHERE Leave_id='$cc_id'");
                      $count_1 = mysqli_num_rows($result_1);
if(isset($_POST['submit'])){
$Sdu_id=$_POST['Sdu_id'];
$cus_id=$Sdu_id;
$Leave_id=$_POST['Leave_id'];

$message=$_POST['message'];
$message_from="Sdutent";
    $status="Panding";
  

    $today= date("d-m-Y");
 
      $file=$_FILES['file']['name']; 
    
        $tmp_name1=$_FILES['file']['tmp_name']; 
    mkdir("Uploads/Customer/Ticket/");
    mkdir("Uploads/Customer/Ticket/".$cus_id."/");  
    mkdir("Uploads/Customer/Ticket/".$cus_id."/".$today."/");
      $path=("Uploads/Customer/Ticket/".$cus_id."/".$today."/");
      move_uploaded_file($tmp_name1,$path.$file);
   
  $sql = mysqli_query($db,"INSERT INTO chat(`Sdu_id`,`Leave_id`,`message`,`massage_from`,`status`,`file`,`path`)VALUES('$Sdu_id','$Leave_id','$message','$message_from','$status','$file','$path')
");
      if($sql){
echo ("<script LANGUAGE='JavaScript'>
    window.alert('Succesfully Updated');
  window.location.href='viewleave.php';
    </script>");
  }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Sdutent - Dashboard</title>
 <link rel="icon" type="image/x-icon" href="img/8.jpg">
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <?php
   include "aside.php";
   ?>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
           <?php
   include "header.php";
   ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Leave Letter</h1>
          

          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Apply Your Leave Online</h6>
            </div>
            <div class="card-body">
            
                <div class="row">
                  <div class="col-12">
          
                  <div class="row Applicable" >
                    <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>Leave ID</lable>
                          <input type="text" class="form-control" id="Leave_id"  name="Leave_id" value="<?php echo $cust_details['Leave_id'];?>" readonly>
                          </div>
                          </div>
                           <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>Name</lable>
                          <input type="text" class="form-control" id="name"  name="name" value="<?php echo $cust_details['name'];?>" readonly>
                          </div>

                          </div>
                            <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>Status</lable>
                            <?php $date = $cust_details['hod_updated_status'];?>
                          <input type="text" class="form-control" id="name"  name="hod_updated_status" value="<?php if ($date==0)  {echo "Pending";
                                                    
                                                   } if($date==1){echo "Approved";
                                                    
                                                   } if($date==2){echo "Rejected";
                                                    
                                                   } ?>" readonly>
                          </div>
                          
                          </div>
                          <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>Leave Created Date</lable>
                          <input type="text" class="form-control" id="name"  name="leave_c_date" value="<?php echo $cust_details['leave_c_date'];?>" readonly>
                          </div>
                          
                          </div>
                        </div>

                  <div class="row Applicable" >
                    <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>From:</lable>
                          <input type="text" class="form-control" id="Leave_id"  name="Leave_id" value="<?php echo $cust_details['from_lea'];?>" readonly>
                          </div>
                          </div>
                      
                        
                          <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>TO:</lable>
                          <input type="text" class="form-control" id="name"  name="leave_c_date" value="<?php echo $cust_details['to_lea'];?>" readonly>
                          </div>
                          
                          </div>
                        </div>
                    <div class="form-group">
                     <textarea class="form-control" name="reason" placeholder="Enter Reason" ><?php echo $cust_details['reason'];?> </textarea>
                    </div>


                                <div class="col-lg-3 col-md-3">
                          <div class="form-group required-field">
                            <lable>Proof</lable>
                            <br>
                        <a href="<?php echo $cust_details['path'].$cust_details['file'];?>" target="_blank"><?php echo $cust_details['file'];?></a>

                          </div>
                          </div>

             <div class="col-lg-6 col-md-6">
                          <div class="form-group required-field">
                            <h4><lable>Chat Now</lable></h4>
                           
                  <?php
                      $result = mysqli_query($db,"SELECT * FROM chat WHERE Leave_id='$cc_id'");
                      $count_1 = mysqli_num_rows($result);
                      
                  if($count_1>0){
                    
                      $result = mysqli_query($db,"SELECT * FROM chat WHERE Leave_id='$cc_id'");
                      
                      while($row = mysqli_fetch_assoc($result)){
                        $massage_from=$row['massage_from'];
                        $message=$row['message'];
                        
                      
                    ?>

                            
                          
        
                           <h6> 

                            <?php echo $massage_from;?> :<?php echo $message;?>

                          <?php } ?>
                            

                          </h6>
                  
                      
  
                          
                          
                          </div>
                        </div>

                          <div class="row">
                   
                          <div class="col-lg-12 col-md-12" >
                
                            <input type="button" id='myButton' class="btn btn-primary" value="Reply">
                        
                      </div>
    
  <?php } ?>
              

                          </div>
                          <br>
                          <div class="tic"  style="display:none;">
  <div class="form-group " >
    <form action="lea_details.php" method="POST" id="form-search"  enctype="multipart/form-data">
      <input type="text" class="form-control" id="Sdu_id"  name="Sdu_id" value="<?php echo $cust_details['Sdu_id'];?>" hidden>
                          
                        
                              <input type="text" class="form-control" id="Leave_id"  name="Leave_id" value="<?php echo $cust_details['Leave_id'];?>" hidden>
 
                     <textarea class="form-control" name="message" placeholder="Enter Reason" > </textarea>
                    </div>
                    <div class="form-group">
                      <input type="file" class="form-control" id="exampleInputPassword" name="file" placeholder="File">
                    </div>
                     <div class="form-group row">
                         <div class="col-lg-6 col-md-6" >
                      <input type="submit" class="btn btn-info"  value="Send" name="submit">
                    </div>
                  </div>
                 
  </div>

</form>
                 
                </div>

                </div>
             
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Dream Tech@ 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="index.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>
      
  <script> 
    
    
    
    
    
  $(document).ready(function(){
  $("#myButton").click(function(){
    $(".tic").show();


  });
 
});

    </script>
</body>

</html>
